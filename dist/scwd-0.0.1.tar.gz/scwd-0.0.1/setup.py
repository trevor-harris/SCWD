from setuptools import setup, find_packages
from setuptools.command.install import install

if __name__ == "__main__":
    setup()